<!DOCTYPE html>
<html>
<head>
  <title>Maryam Eslam Elhossary Portfolio</title>
  <link rel="stylesheet" href="styles.css">
  <meta charset="UTF-8">
</head>
<body>
  <header>
    <h1>Maryam Eslam Elhossary</h1>
    <h2>AI Undergraduate</h2>
  </header>

  <section class="profile">
    <h3>Submit Your Information</h3>
    <form action="form.php" method="POST" enctype="multipart/form-data">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>

      <label for="job_title">Job Title:</label>
      <input type="text" id="job_title" name="job_title" required>

      <label for="image">Profile Image:</label>
      <input type="file" id="image" name="image" accept="image/*" required>

      <button type="submit">Submit</button>
    </form>
  </section>
</body>
</html>
