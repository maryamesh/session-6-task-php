<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $job_title = htmlspecialchars($_POST["job_title"]);

    // Handle Image Upload
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $upload_dir = "uploads/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $image_path = $upload_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $image_path);
    } else {
        $image_path = "default.jpg"; // Fallback image
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Submitted Data</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <h1>Submitted Information</h1>
  </header>

  <section class="profile">
    <img src="<?php echo $image_path; ?>" alt="Profile Image">
    <h2><?php echo $name; ?></h2>
    <p>Email: <?php echo $email; ?></p>
    <p>Job Title: <?php echo $job_title; ?></p>
    <a href="index.php">Go Back</a>
  </section>
</body>
</html>
